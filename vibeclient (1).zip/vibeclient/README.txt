Build the jar:
 A) Local: install JDK 25 + Gradle 9.3+, then run:  gradle build   -> build/libs/vibeclient-0.1.0.jar
 B) GitHub: push this folder to a repo, open Actions > build > download the "vibeclient-jar" artifact.
Install: put the jar + Fabric API in .minecraft/mods (Fabric Loader 0.19.3+, MC 26.2).
Commands: /hack list, /hack toggle <module>
