package dev.vibe.hack;

import dev.vibe.hack.modules.*;
import net.minecraft.client.Minecraft;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = List.of(
        new Sprint(), new Fly(), new Speed(), new Fullbright(),
        new AutoTool(), new AutoEat(), new Aura(),
        new TriggerBot(), new AimAssist(), new AnchorAura()
    );

    public static Module find(String name) {
        for (Module m : MODULES) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(mc);
    }
}
