package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Only acts on anchors YOU place. Once a placed anchor has an enemy player nearby AND a solid block
 * shielding you from the blast, it charges it with glowstone and detonates it. If the shield is
 * missing, it waits (it never detonates unsafely). Does nothing in the Nether (anchors don't explode there).
 */
public class AnchorAura extends Module {
    public static double targetRadius = 5.0;
    private static final List<Placed> pending = new ArrayList<>();
    private static boolean active;

    private static class Placed { BlockPos pos; int age; int stage; Placed(BlockPos p) { pos = p; } }

    public AnchorAura() { super("AnchorAura", Category.COMBAT); }

    /** Called once from VibeClient: records anchors the player places by hand. */
    public static void registerHooks() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (active && level.isClientSide() && player.getItemInHand(hand).is(Items.RESPAWN_ANCHOR))
                pending.add(new Placed(hit.getBlockPos().relative(hit.getDirection())));
            return InteractionResult.PASS;
        });
    }

    @Override protected void onEnable(Minecraft mc) { active = true; pending.clear(); }
    @Override protected void onDisable(Minecraft mc) { active = false; pending.clear(); }

    @Override public void onTick(Minecraft mc) {
        if (pending.isEmpty()) return;
        var p = mc.player;
        if (mc.level.dimension() == Level.NETHER) { pending.clear(); return; }
        Placed pl = pending.get(0);
        pl.age++;
        var state = mc.level.getBlockState(pl.pos);
        if (!state.is(Blocks.RESPAWN_ANCHOR)) {
            if (pl.age > 20) pending.remove(0); // placement failed or anchor gone
            return;
        }
        if (pl.age > 600) { pending.remove(0); return; } // gave up waiting for a safe moment

        if (pl.stage == 0) {
            if (!enemyNearby(mc, pl.pos) || !shielded(mc, p, pl.pos)) return; // wait until safe
            int glow = hotbarSlot(p, true), other = hotbarSlot(p, false);
            if (glow < 0 || other < 0) return;
            int back = p.getInventory().getSelectedSlot();
            if (state.getValue(RespawnAnchorBlock.CHARGE) == 0) {
                p.getInventory().setSelectedSlot(glow);
                interact(mc, pl.pos);
            }
            p.getInventory().setSelectedSlot(back);
            pl.stage = 1;
        } else {
            if (!shielded(mc, p, pl.pos)) return; // shield broke: do not detonate
            if (state.getValue(RespawnAnchorBlock.CHARGE) == 0) { pl.stage = 0; return; }
            int other = hotbarSlot(p, false);
            int back = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(other);
            interact(mc, pl.pos);
            p.getInventory().setSelectedSlot(back);
            pending.remove(0);
        }
    }

    private static void interact(Minecraft mc, BlockPos pos) {
        BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP, pos, false);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private static boolean enemyNearby(Minecraft mc, BlockPos pos) {
        for (Player o : mc.level.players())
            if (o != mc.player && o.isAlive() && o.distanceToSqr(Vec3.atCenterOf(pos)) <= targetRadius * targetRadius) return true;
        return false;
    }

    /** True only if solid blocks stand between the anchor and both your feet and your eyes. */
    private static boolean shielded(Minecraft mc, Player me, BlockPos anchor) {
        Vec3 from = Vec3.atCenterOf(anchor);
        return blocked(mc, from, me.position().add(0, 0.1, 0), anchor)
            && blocked(mc, from, me.getEyePosition(), anchor)
            && blocked(mc, from, me.position().add(0, me.getBbHeight() / 2, 0), anchor);
    }

    private static boolean blocked(Minecraft mc, Vec3 from, Vec3 to, BlockPos ignore) {
        var hit = mc.level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
        return hit.getType() == HitResult.Type.BLOCK && !hit.getBlockPos().equals(ignore);
    }

    private static int hotbarSlot(Player p, boolean glowstone) {
        for (int i = 0; i < 9; i++) {
            boolean g = p.getInventory().getItem(i).is(Items.GLOWSTONE);
            if (glowstone ? g : !g) return i;
        }
        return -1;
    }
}
