package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

public class Speed extends Module {
    public static double multiplier = 1.4;
    public Speed() { super("Speed", Category.MOVEMENT); }
    @Override public void onTick(Minecraft mc) {
        var p = mc.player;
        if (!p.onGround()) return;
        Vec3 v = p.getDeltaMovement();
        if (Math.abs(v.x) + Math.abs(v.z) < 0.01) return;
        p.setDeltaMovement(v.x * multiplier, v.y, v.z * multiplier);
    }
}
