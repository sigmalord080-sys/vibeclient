package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.minecraft.client.Minecraft;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.MOVEMENT); }
    @Override public void onTick(Minecraft mc) { mc.options.keySprint.setDown(true); }
    @Override protected void onDisable(Minecraft mc) { mc.options.keySprint.setDown(false); }
}
