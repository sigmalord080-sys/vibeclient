package dev.vibe.hack;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.network.chat.Component;

public class VibeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(ModuleManager::tick);
        dev.vibe.hack.modules.AnchorAura.registerHooks();

        // /hack list  |  /hack toggle <module>
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            LiteralArgumentBuilder<FabricClientCommandSource> root =
                LiteralArgumentBuilder.<FabricClientCommandSource>literal("hack");

            root.then(LiteralArgumentBuilder.<FabricClientCommandSource>literal("list").executes(ctx -> {
                for (Module m : ModuleManager.MODULES)
                    ctx.getSource().sendFeedback(Component.literal("[" + m.category + "] " + m.name + ": " + (m.isEnabled() ? "ON" : "off")));
                return 1;
            }));

            root.then(LiteralArgumentBuilder.<FabricClientCommandSource>literal("toggle")
                .then(RequiredArgumentBuilder.<FabricClientCommandSource, String>argument("module", StringArgumentType.word())
                    .suggests((c, b) -> {
                        for (Module m : ModuleManager.MODULES) b.suggest(m.name);
                        return b.buildFuture();
                    })
                    .executes(ctx -> {
                        Module m = ModuleManager.find(StringArgumentType.getString(ctx, "module"));
                        if (m == null) { ctx.getSource().sendFeedback(Component.literal("Unknown module")); return 0; }
                        m.toggle();
                        ctx.getSource().sendFeedback(Component.literal(m.name + (m.isEnabled() ? " ON" : " OFF")));
                        return 1;
                    })));

            dispatcher.register(root);
        });
    }
}
