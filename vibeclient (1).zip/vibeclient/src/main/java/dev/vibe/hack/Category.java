package dev.vibe.hack;

public enum Category { COMBAT, MOVEMENT, RENDER, UTILITY }
