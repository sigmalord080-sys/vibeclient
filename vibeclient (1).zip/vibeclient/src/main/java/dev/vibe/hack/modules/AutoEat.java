package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;

public class AutoEat extends Module {
    private boolean eating;
    public AutoEat() { super("AutoEat", Category.UTILITY); }
    @Override public void onTick(Minecraft mc) {
        var p = mc.player;
        if (p.getFoodData().getFoodLevel() > 14) { stop(mc); return; }
        var inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).has(DataComponents.FOOD)) {
                inv.setSelectedSlot(i);
                mc.options.keyUse.setDown(true);
                eating = true;
                return;
            }
        }
        stop(mc);
    }
    private void stop(Minecraft mc) {
        if (eating) { mc.options.keyUse.setDown(false); eating = false; }
    }
    @Override protected void onDisable(Minecraft mc) { stop(mc); }
}
