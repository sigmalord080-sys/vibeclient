package dev.vibe.hack;

import net.minecraft.client.Minecraft;

public abstract class Module {
    public final String name;
    public final Category category;
    private boolean enabled;

    protected Module(String name, Category category) { this.name = name; this.category = category; }

    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        Minecraft mc = Minecraft.getInstance();
        if (enabled) onEnable(mc); else onDisable(mc);
    }

    protected void onEnable(Minecraft mc) {}
    protected void onDisable(Minecraft mc) {}
    public void onTick(Minecraft mc) {}
}
