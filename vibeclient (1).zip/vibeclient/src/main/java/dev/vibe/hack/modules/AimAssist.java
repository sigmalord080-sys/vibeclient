package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

/** While you hold attack, smoothly nudges your aim toward the closest target inside your FOV cone. */
public class AimAssist extends Module {
    public static double range = 4.5, fov = 70, smooth = 0.2;
    public AimAssist() { super("AimAssist", Category.COMBAT); }

    @Override public void onTick(Minecraft mc) {
        if (!mc.options.keyAttack.isDown()) return;
        var p = mc.player;
        double bestAngle = fov;
        float bestDy = 0, bestDp = 0;
        boolean found = false;
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(range))) {
            if (!(e instanceof LivingEntity le) || !le.isAlive() || e instanceof ArmorStand) continue;
            if (p.distanceTo(e) > range) continue;
            Vec3 to = le.getBoundingBox().getCenter().subtract(p.getEyePosition());
            float yaw = (float) (Mth.atan2(to.z, to.x) * 180.0 / Math.PI) - 90f;
            float pitch = (float) -(Mth.atan2(to.y, Math.sqrt(to.x * to.x + to.z * to.z)) * 180.0 / Math.PI);
            float dy = Mth.wrapDegrees(yaw - p.getYRot());
            float dp = pitch - p.getXRot();
            double ang = Math.hypot(dy, dp);
            if (ang < bestAngle) { bestAngle = ang; bestDy = dy; bestDp = dp; found = true; }
        }
        if (!found) return;
        p.setYRot(p.getYRot() + bestDy * (float) smooth);
        p.setXRot(Mth.clamp(p.getXRot() + bestDp * (float) smooth, -90f, 90f));
    }
}
