package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class Aura extends Module {
    public static double range = 3.5;
    public Aura() { super("Aura", Category.COMBAT); }
    @Override public void onTick(Minecraft mc) {
        var p = mc.player;
        if (p.getAttackStrengthScale(0f) < 1f) return;
        Entity best = null;
        double bestDist = range * range;
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(range))) {
            if (!(e instanceof LivingEntity le) || !le.isAlive() || e instanceof Player) continue;
            double d = p.distanceToSqr(e);
            if (d < bestDist) { bestDist = d; best = e; }
        }
        if (best != null) {
            mc.gameMode.attack(p, best);
            p.swing(InteractionHand.MAIN_HAND);
        }
    }
}
