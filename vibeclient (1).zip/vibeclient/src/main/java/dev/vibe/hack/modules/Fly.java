package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/** Velocity-based fly: hold jump to rise, sneak to descend, otherwise hover. */
public class Fly extends Module {
    public static double speed = 0.5;
    public Fly() { super("Fly", Category.MOVEMENT); }

    @Override public void onTick(Minecraft mc) {
        var p = mc.player;
        Vec3 v = p.getDeltaMovement();
        double y = 0;
        if (mc.options.keyJump.isDown()) y = speed;
        else if (mc.options.keyShift.isDown()) y = -speed;
        p.setDeltaMovement(v.x * 1.05, y, v.z * 1.05);
        p.fallDistance = 0;
    }
}
