package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.EntityHitResult;

/** Attacks whatever your crosshair is on, once the attack cooldown is full. */
public class TriggerBot extends Module {
    public TriggerBot() { super("TriggerBot", Category.COMBAT); }
    @Override public void onTick(Minecraft mc) {
        var p = mc.player;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return;
        Entity e = hit.getEntity();
        if (!(e instanceof LivingEntity le) || !le.isAlive() || e instanceof ArmorStand) return;
        if (p.getAttackStrengthScale(0f) < 1f) return;
        mc.gameMode.attack(p, e);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
