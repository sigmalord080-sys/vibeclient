package dev.vibe.hack.modules;

import dev.vibe.hack.Category;
import dev.vibe.hack.Module;
import net.minecraft.client.Minecraft;

public class Fly extends Module {
    public Fly() { super("Fly", Category.MOVEMENT); }
    @Override public void onTick(Minecraft mc) {
        mc.player.getAbilities().setMayFly(true);
        mc.player.getAbilities().setFlyingSpeed(0.08f);
    }
    @Override protected void onDisable(Minecraft mc) {
        if (mc.player == null || mc.player.isCreative() || mc.player.isSpectator()) return;
        mc.player.getAbilities().setFlying(false);
        mc.player.getAbilities().setMayFly(false);
        mc.player.getAbilities().setFlyingSpeed(0.05f);
    }
}
